import http from "../http-common"


class TutorialDataService {


getAllTutorials() {
    //http://85.159.71.66:8080/api/tutorials
    //[{"id":1,"title":"tutorial1",}]
    return http.get("/tutorials");
}

}

export default new TutorialDataService();