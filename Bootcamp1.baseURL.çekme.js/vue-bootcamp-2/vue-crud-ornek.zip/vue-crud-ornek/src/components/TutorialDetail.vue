<script>
export default {
    name : "tutorial-detail"
}
</script>