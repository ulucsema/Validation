<template>
    <div class="col-md-6">
        <h4>Tutorial Listesi </h4>
        <ul>

        </ul>
    </div>
</template>
<script>
import TutorialDataService from "../services/TutorialDataService"
export default {
    name : "tutorials-list",
    data(){
    return {
       tutorials : []
    };
    },
    methods: 
    {
        //http://85.159.71.66:8080/api/tutorials
        tutoriallariGetir() {
        TutorialDataService.getAllTutorials().then(gelenTutorials => {
                this.tutorials = gelenTutorials.data
                console.log(gelenTutorials.data)
        })
        .catch(hata => {
            console.log(hata);
        })
        },
    },
    //sayfa çağrıldığında 
    mounted() {
        this.tutoriallariGetir();
    }
};
</script>